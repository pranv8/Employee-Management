
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, effect } from '@angular/core';
import { Subscription } from 'rxjs';
import type { EChartsOption } from 'echarts';
import * as echarts from 'echarts/core';
import { BarChart } from 'echarts/charts';
import {
  AriaComponent,
  GridComponent,
  TooltipComponent,
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

import { Employee } from '../../interface/employee.interface';
import { EmployeeService } from '../../services/employee.service';
import { ThemeService } from '../../services/theme.service';
import { ChartComponent } from './chart/chart.component';

interface DepartmentCount {
  name: string;
  count: number;
}

interface AgeGroupCount {
  name: string;
  count: number;
}

interface AgeGroupRange {
  name: string;
  min: number;
  max: number;
}

// Age bands shown on the chart, in display order. The first and last bands
// are open-ended so every valid age always lands in exactly one group.
const AGE_GROUPS: readonly AgeGroupRange[] = [
  { name: 'Under 25', min: 0, max: 24 },
  { name: '25–29', min: 25, max: 29 },
  { name: '30–34', min: 30, max: 34 },
  { name: '35–39', min: 35, max: 39 },
  { name: '40–44', min: 40, max: 44 },
  { name: '45–49', min: 45, max: 49 },
  { name: '50+', min: 50, max: Number.POSITIVE_INFINITY },
];

echarts.use([
  BarChart,
  AriaComponent,
  GridComponent,
  TooltipComponent,
  CanvasRenderer,
]);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, ChartComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent implements OnDestroy {
  public departments: DepartmentCount[] = [];
  public ageGroups: AgeGroupCount[] = [];
  public chartOptions: EChartsOption = {};
  public ageChartOptions: EChartsOption = {};
  public totalEmployees = 0;
  public isLoading = true;
  public errorMessage = '';

  private readonly subscription: Subscription;

  public constructor(
    private readonly employeeService: EmployeeService,
    private readonly themeService: ThemeService,
  ) {
    effect(() => {
      this.themeService.theme();
      this.refreshChartOptions();
    });

    this.subscription = this.employeeService.loadEmployees().subscribe({
      next: (employees: Employee[]) => {
        this.totalEmployees = employees.length;
        this.departments = this.groupByDepartment(employees);
        this.ageGroups = this.groupByAgeGroup(employees);
        this.refreshChartOptions();
        this.isLoading = false;
      },
      error: (error: unknown) => {
        console.error('Unable to load dashboard chart data:', error);
        this.errorMessage =
          'Employee data could not be loaded. Please try again.';
        this.isLoading = false;
      },
    });
  }

  private groupByDepartment(employees: Employee[]): DepartmentCount[] {
    const counts = new Map<string, number>();

    for (const employee of employees) {
      const department =
        employee.employeeDepartment?.trim() || 'Unassigned';

      counts.set(department, (counts.get(department) ?? 0) + 1);
    }

    return Array.from(counts.entries())
      .map(([name, count]) => ({ name, count }))
      .sort(
        (a, b) => b.count - a.count || a.name.localeCompare(b.name),
      );
  }

  private groupByAgeGroup(employees: Employee[]): AgeGroupCount[] {
    const counts = AGE_GROUPS.map((group) => ({ name: group.name, count: 0 }));

    for (const employee of employees) {
      const index = AGE_GROUPS.findIndex(
        (group) =>
          employee.employeeAge >= group.min &&
          employee.employeeAge <= group.max,
      );

      if (index !== -1) {
        counts[index].count += 1;
      }
    }

    return counts;
  }

  private refreshChartOptions(): void {
    this.chartOptions = this.createBarChartOptions(this.departments);
    this.ageChartOptions = this.createBarChartOptions(this.ageGroups);
  }

  // Shared builder for every bar chart on the dashboard. All colours are read
  // from the theme CSS variables, so Day and Dusk are handled in one place.
  private createBarChartOptions(
    items: ReadonlyArray<{ name: string; count: number }>,
  ): EChartsOption {
    const styles =
      typeof document === 'undefined'
        ? null
        : getComputedStyle(document.documentElement);
    const color = (property: string, fallback: string): string =>
      styles?.getPropertyValue(property).trim() || fallback;
    const axisLabelColor = color('--chart-axis-label', '#334155');
    const highestCount = Math.max(0, ...items.map((item) => item.count));
    const maxCount = Math.max(3, Math.ceil(highestCount / 3) * 3);

    return {
      aria: {
        enabled: true,
        decal: { show: true },
      },
      animationDuration: 350,
      grid: {
        top: 28,
        right: 20,
        bottom: 58,
        left: 42,
        containLabel: true,
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        backgroundColor: color('--bg-card', '#ffffff'),
        borderColor: color('--border', '#dce4ea'),
        textStyle: { color: color('--text-primary', '#1f2937') },
      },
      xAxis: {
        type: 'category',
        data: items.map((item) => item.name),
        axisTick: { alignWithLabel: true },
        axisLine: {
          lineStyle: { color: color('--border-strong', '#cbd5e1') },
        },
        axisLabel: {
          color: axisLabelColor,
          interval: 0,
          overflow: 'truncate',
          width: 110,
          fontSize: 13,
          fontWeight: 500,
          lineHeight: 16,
          hideOverlap: false,
        },
      },
      yAxis: {
        type: 'value',
        min: 0,
        max: maxCount,
        interval: 3,
        minInterval: 1,
        axisLabel: {
          color: axisLabelColor,
          fontSize: 12,
          fontWeight: 500,
        },
        axisLine: { show: false },
        axisTick: { show: false },
        splitLine: {
          lineStyle: { color: color('--border-soft', '#e2e8f0') },
        },
      },
      series: [
        {
          name: 'Employees',
          type: 'bar',
          data: items.map((item) => item.count),
          barMaxWidth: 44,
          itemStyle: {
            color: color('--primary', '#007f94'),
            borderRadius: [4, 4, 0, 0],
          },
          label: {
            show: true,
            position: 'top',
            color: color('--text-primary', '#1f2937'),
            fontSize: 13,
            fontWeight: 700,
          },
        },
      ],
    };
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
